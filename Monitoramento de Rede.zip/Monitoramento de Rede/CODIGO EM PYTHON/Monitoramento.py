import speedtest
import time
import os
import atexit

# Função para registrar o início do relatório
def iniciar_relatorio():
    with open("resultados_velocidade.txt", "a", encoding="utf-8") as file:
        file.write(f"\nRelatorio iniciado em: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        file.write("\n")  # Adiciona uma linha em branco após o "Relatório iniciado"

# Função para registrar o final do relatório
def finalizar_relatorio():
    with open("resultados_velocidade.txt", "a", encoding="utf-8") as file:
        file.write(f"\nRelatorio finalizado em: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")

# Função para testar a velocidade e salvar os resultados
def testar_velocidade():
    st = speedtest.Speedtest()
    st.get_best_server()
    ping = st.results.ping
    download = round(st.download() / 1_000_000, 2)  # Mbps
    upload = round(st.upload() / 1_000_000, 2)  # Mbps
    resultado = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Ping: {ping}ms | Download: {download} Mbps | Upload: {upload} Mbps\n"
    
    # Salvar no arquivo de texto no mesmo diretório, com codificação UTF-8
    with open("resultados_velocidade.txt", "a", encoding="utf-8") as file:
        file.write(resultado)
    
    # Também imprime o resultado no terminal
    print(resultado)

# Função que será chamada ao encerrar o script, garantindo que o relatório final seja salvo
def encerrar_programa():
    finalizar_relatorio()

# Registrar a função de finalização para ser chamada ao encerrar o script
atexit.register(encerrar_programa)

# Iniciar o relatório
iniciar_relatorio()

# Teste contínuo
try:
    while True:
        testar_velocidade()
        time.sleep(20)  # Espera 20 segundos antes do próximo teste
except KeyboardInterrupt:
    # Esse bloco será chamado se o usuário pressionar Ctrl+C para interromper
    print("\nRelatório finalizado devido à interrupção.")

# Aguardar a entrada do usuário antes de fechar
input("Pressione Enter para sair...")
